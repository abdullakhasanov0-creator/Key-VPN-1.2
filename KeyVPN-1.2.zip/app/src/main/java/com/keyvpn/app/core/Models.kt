package com.keyvpn.app.core

/** Сервер в списке. pingMs: >0 — реальный пинг, 0 — не тестировался, -1 — не отвечает. */
data class Server(
    val id: String,
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val outboundJson: String,
    val subId: String? = null,
    val pingMs: Int = 0,
    val testedAt: Long = 0,
)

/** Подписка (ссылка, отдающая список ключей). */
data class Sub(
    val id: String,
    val url: String,
    val title: String,
    val updatedAt: Long,
    val info: String? = null,
)

data class Parsed(
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val outbound: Map<String, Any?>,
)
