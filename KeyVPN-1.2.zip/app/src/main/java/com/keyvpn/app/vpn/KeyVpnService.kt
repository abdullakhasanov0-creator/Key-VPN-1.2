package com.keyvpn.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.keyvpn.app.core.ConfigBuilder
import com.keyvpn.app.core.Json
import com.keyvpn.app.core.Server
import com.keyvpn.app.data.PingTester
import com.keyvpn.app.data.Settings
import com.keyvpn.app.data.Store
import com.keyvpn.app.ui.MainActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.net.Inet4Address
import java.net.InetAddress

class KeyVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.keyvpn.app.START"
        const val ACTION_STOP = "com.keyvpn.app.STOP"
        const val EXTRA_SERVER = "server"
        private const val CHANNEL = "vpn"
        private const val NOTIF_ID = 1

        /** serverId == null — автовыбор лучшего по пингу. */
        fun start(ctx: Context, serverId: String?) {
            val i = Intent(ctx, KeyVpnService::class.java).setAction(ACTION_START)
            if (serverId != null) i.putExtra(EXTRA_SERVER, serverId)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, KeyVpnService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var pfd: ParcelFileDescriptor? = null
    private var controller: CoreController? = null

    private val handler = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(l: Long, s: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        val requested = intent?.getStringExtra(EXTRA_SERVER)
        // «Постоянный VPN» из настроек Android перезапускает сервис с пустым intent -> авто-режим / последний выбор
        val id = requested ?: if (intent == null && !Settings.autoMode.value) Settings.selectedId else requested
        foreground("Подготовка…")
        job?.cancel()
        job = scope.launch { session(id) }
        return START_STICKY
    }

    // ---------- сессия ----------

    private suspend fun session(requestedId: String?) {
        try {
            VpnState.set(Phase.TESTING, null)
            var server: Server = pick(requestedId) ?: return fail(
                if (Store.servers.value.isEmpty()) "Нет серверов — добавьте ключ" else "Ни один сервер не отвечает"
            )
            while (true) {
                if (!connect(server)) {
                    if (requestedId != null || !Settings.failover.value) return fail("Сервер «${server.name}» не отвечает")
                    Store.setPing(server.id, -1)
                    server = PingTester.best(exclude = setOf(server.id), forceRetest = true) ?: return fail("Ни один сервер не отвечает")
                    continue
                }
                server = watch(server, auto = requestedId == null) ?: return
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fail(e.message ?: "Ошибка подключения")
        }
    }

    private suspend fun pick(requestedId: String?): Server? {
        if (requestedId != null) return Store.get(requestedId)
        return PingTester.best() ?: null
    }

    /** Поднимает tun + ядро Xray и проверяет, что трафик реально идёт. */
    private suspend fun connect(server: Server): Boolean = withContext(Dispatchers.IO) {
        VpnState.set(Phase.CONNECTING, server.id)
        updateNotification("Подключение: ${server.name}")
        stopCore()
        val cfg = ConfigBuilder.full(pinAddress(Json.parseObject(server.outboundJson)))
        val b = Builder()
            .setSession("KeyVPN")
            .setMtu(1500)
            .addAddress("172.19.0.1", 30)
            .addRoute("0.0.0.0", 0)
            .addAddress("fdfe:dcba:9876::1", 126)
            .addRoute("::", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        // само приложение (и Xray) не заворачиваем в туннель — иначе петля
        try { b.addDisallowedApplication(packageName) } catch (_: Exception) {}
        val p = b.establish() ?: throw IllegalStateException("Нет разрешения VPN")
        pfd = p
        val ctl = Libv2ray.newCoreController(handler)
        controller = ctl
        ctl.startLoop(cfg, p.fd)
        // проверка: пинг через поднятый туннель (2 попытки)
        var ms = -1L
        repeat(2) {
            if (ms <= 0) ms = try { ctl.measureDelay(Settings.testUrl) } catch (e: Throwable) { -1L }
        }
        if (ms <= 0) { stopCore(); return@withContext false }
        Store.setPing(server.id, ms.toInt())
        VpnState.set(Phase.CONNECTED, server.id, connectedAt = System.currentTimeMillis())
        updateNotification("Защищено · ${server.name} · $ms мс")
        true
    }

    /** Следит за соединением; в авто-режиме при потере связи переключается на следующий лучший сервер. */
    private suspend fun watch(server: Server, auto: Boolean): Server? {
        var fails = 0
        while (true) {
            delay(20_000)
            val ms = withContext(Dispatchers.IO) {
                try { controller?.measureDelay(Settings.testUrl) ?: -1L } catch (e: Throwable) { -1L }
            }
            if (ms > 0) {
                fails = 0
                Store.setPing(server.id, ms.toInt())
                updateNotification("Защищено · ${server.name} · $ms мс")
                continue
            }
            if (++fails < 2) continue
            if (!auto || !Settings.failover.value) {
                updateNotification("Нет ответа от сервера")
                fails = 0
                continue
            }
            VpnState.set(Phase.TESTING, server.id, "Сервер не отвечает, ищу другой…")
            updateNotification("Ищу другой сервер…")
            Store.setPing(server.id, -1)
            val next = PingTester.best(exclude = setOf(server.id), forceRetest = true)
            if (next == null) { fail("Ни один сервер не отвечает"); return null }
            return next
        }
    }

    /** Подставляет IP вместо домена сервера (резолв вне туннеля), SNI/Host в конфиге уже заданы. */
    @Suppress("UNCHECKED_CAST")
    private fun pinAddress(ob: MutableMap<String, Any?>): Map<String, Any?> {
        try {
            val settings = ob["settings"] as? Map<String, Any?> ?: return ob
            val entry = ((settings["vnext"] ?: settings["servers"]) as? List<Any?>)?.firstOrNull() as? MutableMap<String, Any?> ?: return ob
            val addr = entry["address"] as? String ?: return ob
            if (addr.any { it.isLetter() && it != ':' }) {
                val ip = InetAddress.getAllByName(addr).firstOrNull { it is Inet4Address }?.hostAddress
                if (ip != null) entry["address"] = ip
            }
        } catch (_: Exception) {}
        return ob
    }

    // ---------- остановка ----------

    private fun fail(msg: String) {
        stopCore()
        VpnState.set(Phase.ERROR, message = msg)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopCore() {
        try { controller?.stopLoop() } catch (_: Throwable) {}
        controller = null
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
    }

    private fun shutdown() {
        job?.cancel()
        stopCore()
        VpnState.set(Phase.IDLE, null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() = shutdown()

    override fun onDestroy() {
        job?.cancel()
        stopCore()
        if (VpnState.ui.value.phase != Phase.ERROR) VpnState.set(Phase.IDLE, null)
        scope.cancel()
        super.onDestroy()
    }

    // ---------- уведомление ----------

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, KeyVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("KeyVPN")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Отключить", stop)
            .build()
    }

    private fun foreground(text: String) {
        val n = notification(text)
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        else startForeground(NOTIF_ID, n)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
    }
}
