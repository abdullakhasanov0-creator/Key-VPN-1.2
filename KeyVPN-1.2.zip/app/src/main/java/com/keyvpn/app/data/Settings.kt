package com.keyvpn.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object Settings {
    private lateinit var p: SharedPreferences

    private val _auto = MutableStateFlow(true)
    private val _failover = MutableStateFlow(true)
    private val _autoUpdate = MutableStateFlow(true)

    /** true — «Авто»: подключаться к серверу с наименьшим пингом. */
    val autoMode: StateFlow<Boolean> = _auto.asStateFlow()
    val failover: StateFlow<Boolean> = _failover.asStateFlow()
    val autoUpdate: StateFlow<Boolean> = _autoUpdate.asStateFlow()

    var selectedId: String?
        get() = p.getString("selected", null)
        set(v) { p.edit().putString("selected", v).apply() }

    const val testUrl = "https://www.gstatic.com/generate_204"

    fun init(ctx: Context) {
        p = ctx.getSharedPreferences("keyvpn_settings", Context.MODE_PRIVATE)
        _auto.value = p.getBoolean("auto", true)
        _failover.value = p.getBoolean("failover", true)
        _autoUpdate.value = p.getBoolean("autoUpdate", true)
    }

    fun setAuto(v: Boolean) { _auto.value = v; p.edit().putBoolean("auto", v).apply() }
    fun setFailover(v: Boolean) { _failover.value = v; p.edit().putBoolean("failover", v).apply() }
    fun setAutoUpdate(v: Boolean) { _autoUpdate.value = v; p.edit().putBoolean("autoUpdate", v).apply() }
}
