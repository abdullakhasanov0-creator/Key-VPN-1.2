package com.keyvpn.app.core

/** Сборка полного конфига Xray: tun-inbound (как в Happ) + выбранный outbound. */
object ConfigBuilder {
    private val PRIVATE = listOf(
        "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "169.254.0.0/16",
        "100.64.0.0/10", "fc00::/7", "fe80::/10",
    )

    private val direct = mapOf("tag" to "direct", "protocol" to "freedom")
    private val block = mapOf("tag" to "block", "protocol" to "blackhole")

    fun full(outbound: Map<String, Any?>): String = Json.stringify(linkedMapOf(
        "log" to mapOf("loglevel" to "warning"),
        "dns" to mapOf("servers" to listOf("1.1.1.1", "8.8.8.8")),
        "inbounds" to listOf(mapOf(
            "tag" to "tun", "port" to 0, "protocol" to "tun",
            "settings" to mapOf("name" to "xray0", "MTU" to 1500, "userLevel" to 8),
            "sniffing" to mapOf("enabled" to true, "destOverride" to listOf("http", "tls", "quic")),
        )),
        "outbounds" to listOf(outbound, direct, block),
        "routing" to mapOf(
            "domainStrategy" to "AsIs",
            "rules" to listOf(mapOf("type" to "field", "ip" to PRIVATE, "outboundTag" to "direct")),
        ),
    ))

    /** Минимальный конфиг для замера реального пинга (без inbound). */
    fun probe(outbound: Map<String, Any?>): String = Json.stringify(linkedMapOf(
        "log" to mapOf("loglevel" to "none"),
        "outbounds" to listOf(outbound, direct),
    ))
}
