package com.keyvpn.app.core

import java.net.URLDecoder

/** Разбор ключей vless:// vmess:// trojan:// ss:// и подписок (список ссылок / base64) в outbound-ы Xray. */
object LinkParser {
    private val linkRe = Regex("(?i)(?<![A-Za-z0-9])(vless|vmess|trojan|ss)://[^\\s\"'<>]+")

    fun parseAny(text: String): List<Parsed> {
        val t = text.trim()
        if (t.isEmpty()) return emptyList()
        val direct = linkRe.findAll(t).map { it.value }.toList()
        if (direct.isNotEmpty()) return direct.mapNotNull { parseLink(it) }
        if (t.startsWith("[") || t.startsWith("{")) return parseJsonConfigs(t)
        val decoded = decodeBase64(t)?.let { String(it, Charsets.UTF_8) } ?: return emptyList()
        val fromLinks = linkRe.findAll(decoded).map { it.value }.toList().mapNotNull { parseLink(it) }
        if (fromLinks.isNotEmpty()) return fromLinks
        val d = decoded.trim()
        return if (d.startsWith("[") || d.startsWith("{")) parseJsonConfigs(d) else emptyList()
    }

    /** Подписка в виде JSON: массив (или один) полных конфигов Xray с outbounds. */
    private fun parseJsonConfigs(text: String): List<Parsed> = try {
        val root = Json.parse(text)
        val items: List<Any?> = if (root is List<*>) root else listOf(root)
        val res = ArrayList<Parsed>()
        for (item in items) {
            val cfg = item as? Map<*, *> ?: continue
            val remarks = cfg["remarks"]?.toString()?.trim().orEmpty()
            val outs = cfg["outbounds"] as? List<*> ?: continue
            for (o in outs) {
                val ob = o as? Map<*, *> ?: continue
                val proto = ob["protocol"]?.toString()?.lowercase() ?: continue
                if (proto !in setOf("vless", "vmess", "trojan", "shadowsocks")) continue
                val st = ob["settings"] as? Map<*, *> ?: continue
                val first = ((st["vnext"] ?: st["servers"]) as? List<*>)?.firstOrNull() as? Map<*, *> ?: st
                val host = first["address"]?.toString() ?: continue
                val port = (first["port"] as? Number)?.toInt() ?: first["port"]?.toString()?.toIntOrNull() ?: continue
                @Suppress("UNCHECKED_CAST")
                val outMap = LinkedHashMap(ob as Map<String, Any?>)
                outMap["tag"] = "proxy"
                val name = remarks.ifBlank { ob["tag"]?.toString().orEmpty() }.ifBlank { "$host:$port" }
                res += Parsed(name, if (proto == "shadowsocks") "ss" else proto, host, port, outMap)
                break
            }
        }
        res
    } catch (e: Exception) {
        emptyList()
    }

    fun parseLink(link: String): Parsed? = try {
        when (link.substringBefore("://").lowercase()) {
            "vless" -> vless(link)
            "vmess" -> vmess(link)
            "trojan" -> trojan(link)
            "ss" -> shadowsocks(link)
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    // ---------- протоколы ----------

    private fun vless(link: String): Parsed? {
        val u = url(link) ?: return null
        val id = u.user ?: return null
        val user = linkedMapOf<String, Any?>("id" to id, "encryption" to (u.q["encryption"] ?: "none"), "level" to 8)
        u.q["flow"]?.takeIf { it.isNotEmpty() }?.let { user["flow"] = it }
        val settings = mapOf("vnext" to listOf(mapOf("address" to u.host, "port" to u.port, "users" to listOf(user))))
        return Parsed(nameOf(u), "vless", u.host, u.port, outbound("vless", settings, stream(u.q, u.host, "none")))
    }

    private fun trojan(link: String): Parsed? {
        val u = url(link) ?: return null
        val pass = u.user ?: return null
        val settings = mapOf("servers" to listOf(mapOf("address" to u.host, "port" to u.port, "password" to pass, "level" to 8)))
        return Parsed(nameOf(u), "trojan", u.host, u.port, outbound("trojan", settings, stream(u.q, u.host, "tls")))
    }

    private fun vmess(link: String): Parsed? {
        val body = link.substring(link.indexOf("://") + 3)
        val raw = decodeBase64(body.substringBefore('#').trim())?.let { String(it, Charsets.UTF_8) }
        if (raw == null || !raw.trimStart().startsWith("{")) {
            // новый формат vmess://uuid@host:port?...
            val u = url(link) ?: return null
            val id = u.user ?: return null
            val user = mapOf("id" to id, "alterId" to 0, "security" to (u.q["encryption"] ?: "auto"), "level" to 8)
            val settings = mapOf("vnext" to listOf(mapOf("address" to u.host, "port" to u.port, "users" to listOf(user))))
            return Parsed(nameOf(u), "vmess", u.host, u.port, outbound("vmess", settings, stream(u.q, u.host, "none")))
        }
        val j = Json.parseObject(raw)
        fun s(k: String) = j[k]?.toString()?.trim().orEmpty()
        val host = s("add")
        val port = s("port").toIntOrNull() ?: return null
        if (host.isEmpty() || s("id").isEmpty()) return null
        val net = s("net").ifEmpty { "tcp" }
        val q = hashMapOf(
            "type" to net, "host" to s("host"), "path" to s("path"), "headertype" to s("type"),
            "security" to (if (s("tls").equals("tls", true)) "tls" else "none"),
            "sni" to s("sni"), "alpn" to s("alpn"), "fp" to s("fp"),
            "servicename" to s("path"), "mode" to s("type"),
        )
        val user = mapOf(
            "id" to s("id"), "alterId" to (s("aid").toIntOrNull() ?: 0),
            "security" to s("scy").ifEmpty { "auto" }, "level" to 8,
        )
        val settings = mapOf("vnext" to listOf(mapOf("address" to host, "port" to port, "users" to listOf(user))))
        val name = s("ps").ifEmpty { "$host:$port" }
        return Parsed(name, "vmess", host, port, outbound("vmess", settings, stream(q, host, "none")))
    }

    private fun shadowsocks(link: String): Parsed? {
        var rest = link.substring(5)
        var name = ""
        val hi = rest.indexOf('#')
        if (hi >= 0) { name = dec(rest.substring(hi + 1)); rest = rest.substring(0, hi) }
        val qi = rest.indexOf('?')
        if (qi >= 0) rest = rest.substring(0, qi)
        rest = rest.trimEnd('/')
        val userInfo: String
        val hostPort: String
        if (rest.contains('@')) {
            val at = rest.lastIndexOf('@')
            val ui = rest.substring(0, at)
            hostPort = rest.substring(at + 1)
            userInfo = if (ui.contains(':')) dec(ui) else String(decodeBase64(ui) ?: return null, Charsets.UTF_8)
        } else {
            val d = String(decodeBase64(rest) ?: return null, Charsets.UTF_8)
            val at = d.lastIndexOf('@')
            if (at < 0) return null
            userInfo = d.substring(0, at)
            hostPort = d.substring(at + 1)
        }
        val c = userInfo.indexOf(':')
        if (c < 0) return null
        val method = userInfo.substring(0, c)
        val password = userInfo.substring(c + 1)
        val (host, port) = hostPort(hostPort) ?: return null
        val settings = mapOf("servers" to listOf(mapOf("address" to host, "port" to port, "method" to method, "password" to password, "level" to 8)))
        return Parsed(name.ifBlank { "$host:$port" }, "ss", host, port, outbound("shadowsocks", settings, null))
    }

    // ---------- streamSettings ----------

    private fun outbound(protocol: String, settings: Map<String, Any?>, stream: Map<String, Any?>?): Map<String, Any?> {
        val o = linkedMapOf<String, Any?>("tag" to "proxy", "protocol" to protocol, "settings" to settings)
        if (stream != null) o["streamSettings"] = stream
        return o
    }

    private fun stream(q: Map<String, String>, host: String, defaultSecurity: String): Map<String, Any?> {
        val net = when (val t = (q["type"] ?: "tcp").lowercase()) {
            "http" -> "h2"
            "splithttp" -> "xhttp"
            "" -> "tcp"
            else -> t
        }
        val sec = (q["security"] ?: "").lowercase().ifEmpty { defaultSecurity }
        val sni = q["sni"].orEmpty()
        val path = q["path"].orEmpty()
        val effHost = (q["host"].orEmpty()).ifEmpty { sni.ifEmpty { host } }
        val s = linkedMapOf<String, Any?>("network" to net, "security" to sec)
        when (net) {
            "tcp" -> if ((q["headertype"] ?: "none").lowercase() == "http") {
                s["tcpSettings"] = mapOf("header" to mapOf("type" to "http", "request" to mapOf(
                    "path" to csv(path.ifEmpty { "/" }), "headers" to mapOf("Host" to csv(effHost)))))
            }
            "ws" -> s["wsSettings"] = mapOf("path" to path.ifEmpty { "/" }, "headers" to mapOf("Host" to effHost))
            "grpc" -> {
                val g = linkedMapOf<String, Any?>("serviceName" to (q["servicename"] ?: path), "multiMode" to ((q["mode"] ?: "") == "multi"))
                q["authority"]?.takeIf { it.isNotEmpty() }?.let { g["authority"] = it }
                s["grpcSettings"] = g
            }
            "h2" -> s["httpSettings"] = mapOf("path" to path.ifEmpty { "/" }, "host" to csv(effHost))
            "httpupgrade" -> s["httpupgradeSettings"] = mapOf("path" to path.ifEmpty { "/" }, "host" to effHost)
            "xhttp" -> {
                val x = linkedMapOf<String, Any?>("path" to path.ifEmpty { "/" }, "host" to effHost, "mode" to (q["mode"]?.ifEmpty { null } ?: "auto"))
                q["extra"]?.takeIf { it.startsWith("{") }?.let { try { x["extra"] = Json.parse(it) } catch (_: Exception) {} }
                s["xhttpSettings"] = x
            }
            "kcp" -> {
                val k = linkedMapOf<String, Any?>("header" to mapOf("type" to (q["headertype"]?.ifEmpty { null } ?: "none")))
                q["seed"]?.takeIf { it.isNotEmpty() }?.let { k["seed"] = it }
                s["kcpSettings"] = k
            }
        }
        val fp = q["fp"]?.ifEmpty { null } ?: "chrome"
        when (sec) {
            "tls" -> {
                val t = linkedMapOf<String, Any?>("serverName" to sni.ifEmpty { host }, "fingerprint" to fp,
                    "allowInsecure" to (q["allowinsecure"] == "1" || q["insecure"] == "1" || q["allowinsecure"] == "true"))
                q["alpn"]?.takeIf { it.isNotEmpty() }?.let { t["alpn"] = csv(it) }
                s["tlsSettings"] = t
            }
            "reality" -> s["realitySettings"] = linkedMapOf(
                "serverName" to sni.ifEmpty { host }, "fingerprint" to fp,
                "publicKey" to q["pbk"].orEmpty(), "shortId" to q["sid"].orEmpty(), "spiderX" to q["spx"].orEmpty(),
            )
        }
        return s
    }

    // ---------- утилиты URL ----------

    private class U(val user: String?, val host: String, val port: Int, val q: Map<String, String>, val frag: String)

    private fun nameOf(u: U) = u.frag.ifBlank { "${u.host}:${u.port}" }

    private fun url(link: String): U? {
        val si = link.indexOf("://")
        if (si < 0) return null
        var rest = link.substring(si + 3)
        var frag = ""
        val hi = rest.indexOf('#')
        if (hi >= 0) { frag = dec(rest.substring(hi + 1)); rest = rest.substring(0, hi) }
        var qs = ""
        val qi = rest.indexOf('?')
        if (qi >= 0) { qs = rest.substring(qi + 1); rest = rest.substring(0, qi) }
        val slash = rest.indexOf('/')
        if (slash >= 0) rest = rest.substring(0, slash)
        var user: String? = null
        val at = rest.lastIndexOf('@')
        if (at >= 0) { user = dec(rest.substring(0, at)); rest = rest.substring(at + 1) }
        val (host, port) = hostPort(rest) ?: return null
        val q = HashMap<String, String>()
        for (part in qs.split('&')) {
            if (part.isEmpty()) continue
            val eq = part.indexOf('=')
            val k = (if (eq < 0) part else part.substring(0, eq)).lowercase()
            q[k] = if (eq < 0) "" else dec(part.substring(eq + 1))
        }
        return U(user, host, port, q, frag)
    }

    private fun hostPort(s: String): Pair<String, Int>? {
        if (s.startsWith("[")) {
            val e = s.indexOf(']')
            if (e < 0) return null
            val port = s.substring(e + 1).removePrefix(":").toIntOrNull() ?: 443
            return s.substring(1, e) to port
        }
        val c = s.lastIndexOf(':')
        if (c < 0) return if (s.isEmpty()) null else s to 443
        val port = s.substring(c + 1).toIntOrNull() ?: return null
        val host = s.substring(0, c)
        return if (host.isEmpty()) null else host to port
    }

    private fun csv(s: String): List<String> = s.split(',').map { it.trim() }.filter { it.isNotEmpty() }

    private fun dec(s: String): String = try {
        URLDecoder.decode(s.replace("+", "%2B"), "UTF-8")
    } catch (e: Exception) {
        s
    }

    fun decodeBase64(input: String): ByteArray? {
        val s = input.filter { !it.isWhitespace() && it != '=' }
        if (s.isEmpty()) return null
        val out = java.io.ByteArrayOutputStream()
        var buf = 0
        var bits = 0
        for (ch in s) {
            val v = when (ch) {
                in 'A'..'Z' -> ch - 'A'
                in 'a'..'z' -> ch - 'a' + 26
                in '0'..'9' -> ch - '0' + 52
                '+', '-' -> 62
                '/', '_' -> 63
                else -> return null
            }
            buf = ((buf shl 6) or v) and 0xFFFFFF
            bits += 6
            if (bits >= 8) { bits -= 8; out.write((buf shr bits) and 0xFF) }
        }
        return out.toByteArray()
    }
}
