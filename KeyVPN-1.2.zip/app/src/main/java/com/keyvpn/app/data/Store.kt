package com.keyvpn.app.data

import android.content.Context
import android.content.SharedPreferences
import com.keyvpn.app.core.Json
import com.keyvpn.app.core.Links
import com.keyvpn.app.core.Parsed
import com.keyvpn.app.core.Server
import com.keyvpn.app.core.Sub
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Хранилище серверов и подписок (JSON в SharedPreferences). */
object Store {
    private lateinit var prefs: SharedPreferences
    private val lock = Any()
    private val _servers = MutableStateFlow<List<Server>>(emptyList())
    private val _subs = MutableStateFlow<List<Sub>>(emptyList())
    val servers: StateFlow<List<Server>> = _servers.asStateFlow()
    val subs: StateFlow<List<Sub>> = _subs.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("keyvpn_store", Context.MODE_PRIVATE)
        try {
            _servers.value = (Json.parse(prefs.getString("servers", "[]")!!) as List<*>).mapNotNull { x ->
                val m = x as? Map<*, *> ?: return@mapNotNull null
                Server(
                    id = m["id"] as String, name = m["name"] as String, protocol = m["protocol"] as String,
                    host = m["host"] as String, port = (m["port"] as Number).toInt(), outboundJson = m["ob"] as String,
                    subId = m["sub"] as String?, pingMs = (m["ping"] as? Number)?.toInt() ?: 0,
                    testedAt = (m["tested"] as? Number)?.toLong() ?: 0,
                )
            }
            _subs.value = (Json.parse(prefs.getString("subs", "[]")!!) as List<*>).mapNotNull { x ->
                val m = x as? Map<*, *> ?: return@mapNotNull null
                Sub(m["id"] as String, m["url"] as String, m["title"] as String,
                    (m["updated"] as Number).toLong(), m["info"] as String?)
            }
        } catch (e: Exception) {
            _servers.value = emptyList(); _subs.value = emptyList()
        }
    }

    private fun persist() {
        prefs.edit()
            .putString("servers", Json.stringify(_servers.value.map {
                mapOf("id" to it.id, "name" to it.name, "protocol" to it.protocol, "host" to it.host, "port" to it.port,
                    "ob" to it.outboundJson, "sub" to it.subId, "ping" to it.pingMs, "tested" to it.testedAt)
            }))
            .putString("subs", Json.stringify(_subs.value.map {
                mapOf("id" to it.id, "url" to it.url, "title" to it.title, "updated" to it.updatedAt, "info" to it.info)
            }))
            .apply()
    }

    private fun make(p: Parsed, subId: String?, old: Server?): Server {
        val ob = Json.stringify(p.outbound)
        return Server(
            id = Links.sha1(ob + (subId ?: "")), name = p.name, protocol = p.protocol, host = p.host, port = p.port,
            outboundJson = ob, subId = subId, pingMs = old?.pingMs ?: 0, testedAt = old?.testedAt ?: 0,
        )
    }

    fun get(id: String?): Server? = _servers.value.firstOrNull { it.id == id }

    /** Добавляет ключи; возвращает только реально новые серверы. */
    fun add(list: List<Parsed>, subId: String?): List<Server> = synchronized(lock) {
        val cur = _servers.value.toMutableList()
        val added = ArrayList<Server>()
        for (p in list) {
            val s = make(p, subId, null)
            if (cur.none { it.id == s.id }) { cur += s; added += s }
        }
        _servers.value = cur
        persist()
        added
    }

    /** Заменяет серверы подписки, сохраняя результаты пинга для тех же ключей. */
    fun replaceSub(subId: String, list: List<Parsed>): List<Server> = synchronized(lock) {
        val old = _servers.value.filter { it.subId == subId }.associateBy { it.id }
        val fresh = LinkedHashMap<String, Server>()
        for (p in list) {
            val s = make(p, subId, null)
            fresh[s.id] = s.copy(pingMs = old[s.id]?.pingMs ?: 0, testedAt = old[s.id]?.testedAt ?: 0)
        }
        _servers.value = _servers.value.filter { it.subId != subId } + fresh.values
        persist()
        fresh.values.filter { it.id !in old }
    }

    fun upsertSub(sub: Sub) = synchronized(lock) {
        _subs.value = _subs.value.filter { it.id != sub.id } + sub
        persist()
    }

    fun removeSub(id: String) = synchronized(lock) {
        _subs.value = _subs.value.filter { it.id != id }
        _servers.value = _servers.value.filter { it.subId != id }
        persist()
    }

    fun removeServer(id: String) = synchronized(lock) {
        _servers.value = _servers.value.filter { it.id != id }
        persist()
    }

    fun setPing(id: String, ms: Int) = synchronized(lock) {
        _servers.value = _servers.value.map { if (it.id == id) it.copy(pingMs = ms, testedAt = System.currentTimeMillis()) else it }
        persist()
    }
}
